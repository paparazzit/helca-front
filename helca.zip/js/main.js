$(document).ready(function () {
	$(".owl-carousel").owlCarousel({
		loop: true,
		margin: 10,
		nav: false,
		autoplay: true,
		autoplayTimeout: 100000,

		responsive: {
			0: {
				items: 1,
			},
			600: {
				items: 1,
			},
			1000: {
				items: 1,
			},
		},
	});
	$(".sidebar h2").addClass("animateH2");
	$(".cta form").addClass("animateH2");
});

var owl = $(".owl-carousel");

$(".customNextBtn").click(function () {
	owl.trigger("next.owl.carousel");
});

$(".customPrevBtn").click(function () {
	owl.trigger("prev.owl.carousel", [300]);
});

$(".dropdownLink").click(function () {
	$(".dropdown").toggleClass("dropdown-active");
});

$(".owl-carousel").animate({ opacity: "1" }, 1000);

var width = $(window).width();
// window.onresize = function () {
// 	location.reload();
// };
if (width < 890) {
	$(".float-bg").animate({ top: "-100%" }, 800);
	$(".pozadina").animate({ top: "0" }, 800);
	$(".left .content").animate({ opacity: "1" }, 400);
} else {
	$(".float-bg").animate({ left: "-100%" }, 800);
	$(".pozadina").animate({ left: "0" }, 800);
	$(".left .content").animate({ opacity: "1" }, 400);
}

$(window).scroll(function () {
	if ($("#leaf").visible() && width > 450) {
		$(".float-cube").delay(400).animate({ left: "100%" }, 800);
	}
	if ($("#box").visible() && width <= 450) {
		$(".float-cube").animate({ top: "-100%" }, 800);
	}
	if ($(".one").visible()) {
		$(".one .float").animate({ left: "0%" }, 800);
		$(".four .float").animate({ left: "0%" }, 800);
	}
});
